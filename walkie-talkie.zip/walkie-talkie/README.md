# Walkie-Talkie App

A walkie-talkie style Android app: big push-to-talk button, plus a text chat.
It supports three ways to connect:

- **Bluetooth** — direct phone-to-phone, no network needed at all.
- **Wi-Fi Local** — works when both phones are on the same Wi-Fi network or
  one is sharing a hotspot the other joined. No internet needed.
- **Internet** — talk to someone anywhere by their username, using a small
  relay server (included, in `/relay-server`).

I can't compile a `.apk` file myself in this chat — there's no Android
build tooling here. Below are **two ways** to turn this project into an
installable APK. Option A needs no software install at all. Option B uses
Android Studio and is better if you want to tweak the code yourself.

---

## Option A — Build in the cloud with GitHub Actions (no install, ~10 min)

This project already includes a build robot (`.github/workflows/build-apk.yml`)
that compiles the APK for you automatically. You just need a free GitHub
account.

1. Go to https://github.com and sign up (free) if you don't have an account.
2. Click the **+** icon top-right → **New repository**. Name it anything
   (e.g. `walkie-talkie`), leave it Public or Private, click **Create
   repository**. Don't add a README/gitignore — leave it empty.
3. On the new repo's page, click **uploading an existing file** (a link on
   the empty-repo screen).
4. Unzip `walkie-talkie.zip` on your computer first. Then drag the
   **contents** of the unzipped `walkie-talkie` folder (not the folder
   itself — its contents: `app`, `.github`, `build.gradle`, etc.) into the
   GitHub upload box. Wait for the upload bar to finish, then click
   **Commit changes** at the bottom.
5. Click the **Actions** tab at the top of the repo. You should see a
   workflow run called "Build APK" already running (a yellow dot). Click it
   and wait — it takes 3-6 minutes. A green checkmark means it succeeded.
6. Once it's green, scroll down on that run's page to **Artifacts** and
   click **walkie-talkie-debug-apk** to download a zip containing your
   `app-debug.apk`.
7. If it turns red (failed) instead, click into the failed step to see the
   error text and send it to me — I'll fix the code.

That APK file is what you install on your phone (see "Install it on a
phone" below).

## Option B — Build locally with Android Studio (~20-30 min, lets you edit code)

Use this if Option A's error is hard to fix remotely, or if you want to set
your own Internet-mode server address (see "Internet mode setup" below).

1. Go to https://developer.android.com/studio and download **Android
   Studio**. Install it with default settings; let it finish downloading
   SDK components on first launch.
2. Unzip `walkie-talkie.zip` and in Android Studio: **File → Open** → select
   the unzipped `walkie-talkie` folder → **OK**. Wait for "Gradle sync" in
   the bottom bar to finish (first time takes a few minutes).
3. **Build → Build Bundle(s) / APK(s) → Build APK(s)**. When it finishes,
   click **locate** in the notification, or find it at
   `walkie-talkie/app/build/outputs/apk/debug/app-debug.apk`.

---

## Internet mode setup (optional, for both options)

Bluetooth and Wi-Fi Local mode work with zero setup. If you also want the
**Internet / username** mode to work between phones on different networks,
deploy the small relay server once:

1. Create a free account at https://render.com (or Railway, Fly.io — any
   Node.js host works).
2. Create a new **Web Service** pointing at the `relay-server` folder
   (easiest if you push this project to your own GitHub repo first, which
   you'll already have done if you used Option A above).
   - Build command: `npm install`
   - Start command: `npm start`
3. Render gives you a URL like `https://walkie-talkie-relay.onrender.com`.
   Your app needs it as `wss://walkie-talkie-relay.onrender.com/ws`
   (`https` → `wss`, plus `/ws` on the end).
4. Edit `app/src/main/java/com/walkietalkie/app/InternetTransport.kt`,
   change this line near the top to your URL, then rebuild (Option A: just
   commit the change on GitHub and Actions rebuilds automatically; Option B:
   save and re-run Build APK):
   ```kotlin
   const val RELAY_URL = "wss://YOUR-RELAY-SERVER-URL/ws"
   ```

---

## Install it on a phone

Email yourself the `app-debug.apk` file, or upload it to Google
Drive/Dropbox, open it on your phone, and tap it to install. Android will
warn about installing from an unknown source the first time — tap
**Settings** on that warning, allow installs from that app (e.g. Gmail or
Files), then go back and tap the APK again to install.

Repeat on a second phone to actually test the walkie-talkie functionality
between two devices.

## Using the app

- **Bluetooth mode**: pair the two phones in Android's Bluetooth settings
  first (or just get them close — the app also lists nearby unpaired
  devices it finds), then tap a device in the list to connect.
- **Wi-Fi Local mode**: connect both phones to the same Wi-Fi network (or
  turn on a mobile hotspot on one phone and join it from the other) — they
  should discover each other automatically within a few seconds.
- **Internet mode**: each person types a username and taps Connect, then
  types the other person's username in "Talk to" and taps Connect again.
  Both people need the app open at the same time.
- Hold the big red button to talk, like a real walkie-talkie. Tap the small
  envelope icon (top right) to open text chat instead.

## Known limitations (this is a working prototype, not a polished product)

- Audio is sent uncompressed (raw PCM), so Internet mode uses more data
  than a commercial app — fine on Wi-Fi/Bluetooth, noticeable on cellular.
- No group calls — one-to-one only, per mode.
- No message history — closing the app clears the chat.
- The relay server has no login/passwords, so anyone who knows a username
  you're using could message that "identity" — fine for friends/family use,
  not meant for sensitive use.
- Bluetooth on Android 12+ requires granting "Nearby devices" permission
  when first asked — make sure to tap Allow.

If a build fails (either option), copy the red error text and send it to
me — I'll fix the underlying code.
