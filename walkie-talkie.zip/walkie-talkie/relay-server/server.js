// Minimal WebSocket relay for the Walkie-Talkie app's "Internet" mode.
//
// What it does: each phone connects and registers a username. When phone A
// sends a message addressed "to" phone B's username, this server forwards
// it straight to B's open connection. It does not store any messages -
// if the target username isn't currently online, the sender gets an error.
//
// Run locally:   npm install && npm start
// Deploy: any Node host works (Render, Railway, Fly.io, a small VPS, etc).
// See README.md in this folder for a free step-by-step deploy guide.

const { WebSocketServer } = require('ws');
const http = require('http');

const PORT = process.env.PORT || 8080;

const server = http.createServer((req, res) => {
  res.writeHead(200, { 'Content-Type': 'text/plain' });
  res.end('Walkie-Talkie relay server is running.\n');
});

const wss = new WebSocketServer({ server, path: '/ws' });

// username (lowercase) -> ws connection
const clients = new Map();

function send(ws, obj) {
  if (ws && ws.readyState === ws.OPEN) {
    ws.send(JSON.stringify(obj));
  }
}

wss.on('connection', (ws) => {
  let username = null;

  ws.on('message', (raw) => {
    let msg;
    try {
      msg = JSON.parse(raw.toString());
    } catch (e) {
      return; // ignore malformed input
    }

    if (msg.type === 'register') {
      username = String(msg.username || '').trim().toLowerCase();
      if (!username) return;
      clients.set(username, ws);
      send(ws, { type: 'registered' });
      console.log(`registered: ${username} (${clients.size} online)`);
      return;
    }

    if (msg.type === 'text' || msg.type === 'audio') {
      const to = String(msg.to || '').trim().toLowerCase();
      const target = clients.get(to);
      if (!target) {
        send(ws, { type: 'error', message: `"${msg.to}" is not online right now` });
        return;
      }
      // Forward as-is, the 'from' field already identifies the sender.
      send(target, msg);
      return;
    }
  });

  ws.on('close', () => {
    if (username && clients.get(username) === ws) {
      clients.delete(username);
      console.log(`disconnected: ${username} (${clients.size} online)`);
    }
  });
});

server.listen(PORT, () => {
  console.log(`Walkie-Talkie relay listening on port ${PORT}`);
});
