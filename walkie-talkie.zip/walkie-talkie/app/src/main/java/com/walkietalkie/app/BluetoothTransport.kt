package com.walkietalkie.app

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothServerSocket
import android.bluetooth.BluetoothSocket
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.util.UUID
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Direct phone-to-phone link over classic Bluetooth (RFCOMM/SPP). Works with
 * no Wi-Fi and no internet, as long as both phones have Bluetooth on and are
 * paired (or in discovery range). One side accepts, the other connects - the
 * app runs both a server-accept thread and a client-connect path so either
 * phone can initiate.
 */
class BluetoothTransport(
    private val context: Context,
    private val myName: String,
    private val listener: TransportListener
) : Transport {

    companion object {
        // Standard Serial Port Profile UUID - works across all Android devices.
        val SPP_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
        private const val SERVICE_NAME = "WalkieTalkie"
    }

    private val adapter: BluetoothAdapter? = BluetoothAdapter.getDefaultAdapter()
    private var serverSocket: BluetoothServerSocket? = null
    private var activeSocket: BluetoothSocket? = null
    private var inputStream: InputStream? = null
    private var outputStream: OutputStream? = null
    private val running = AtomicBoolean(false)
    private val peers = CopyOnWriteArrayList<PeerDevice>()
    private var peerName: String = ""

    private val discoveryReceiver = object : BroadcastReceiver() {
        @SuppressLint("MissingPermission")
        override fun onReceive(ctx: Context, intent: Intent) {
            when (intent.action) {
                BluetoothDevice.ACTION_FOUND -> {
                    val device: BluetoothDevice? =
                        intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
                    device ?: return
                    val name = device.name ?: "Unknown device"
                    if (peers.none { it.id == device.address }) {
                        peers.add(PeerDevice(device.address, name))
                        listener.onPeerListChanged(peers.toList())
                    }
                }
            }
        }
    }

    @SuppressLint("MissingPermission")
    override fun start() {
        if (adapter == null) {
            listener.onError("This device has no Bluetooth adapter")
            return
        }
        if (!adapter.isEnabled) {
            listener.onError("Turn Bluetooth on to use this mode")
            return
        }
        running.set(true)
        peers.clear()

        // Seed the list with already-paired devices - no discovery/location needed for these.
        adapter.bondedDevices?.forEach { device ->
            peers.add(PeerDevice(device.address, "${device.name ?: device.address} (paired)"))
        }
        listener.onPeerListChanged(peers.toList())

        context.registerReceiver(discoveryReceiver, IntentFilter(BluetoothDevice.ACTION_FOUND))
        try {
            adapter.startDiscovery()
        } catch (_: SecurityException) {
            listener.onError("Missing Bluetooth permission for discovery")
        }

        listener.onStatus("Bluetooth: scanning for nearby devices…")
        startServerAcceptLoop()
    }

    @SuppressLint("MissingPermission")
    private fun startServerAcceptLoop() {
        Thread {
            try {
                serverSocket = adapter?.listenUsingRfcommWithServiceRecord(SERVICE_NAME, SPP_UUID)
                while (running.get()) {
                    val socket = try {
                        serverSocket?.accept()
                    } catch (e: Exception) {
                        null
                    } ?: break
                    attachSocket(socket, socket.remoteDevice.name ?: "Peer")
                    break
                }
            } catch (e: SecurityException) {
                listener.onError("Missing Bluetooth permission")
            }
        }.start()
    }

    @SuppressLint("MissingPermission")
    override fun connectTo(peerId: String) {
        val adapter = this.adapter ?: return
        val peer = peers.find { it.id == peerId } ?: return
        Thread {
            try {
                adapter.cancelDiscovery()
                val device = adapter.getRemoteDevice(peerId)
                val socket = device.createRfcommSocketToServiceRecord(SPP_UUID)
                socket.connect()
                attachSocket(socket, peer.displayName)
            } catch (e: Exception) {
                listener.onError("Bluetooth connect failed: ${e.message}")
            }
        }.start()
    }

    private fun attachSocket(socket: BluetoothSocket, name: String) {
        activeSocket = socket
        inputStream = socket.inputStream
        outputStream = socket.outputStream
        peerName = name
        listener.onConnected(name)
        listener.onStatus("Bluetooth: connected to $name")
        Thread { readLoop() }.start()
    }

    private fun readLoop() {
        val stream = inputStream ?: return
        val header = ByteArray(2)
        while (running.get()) {
            try {
                if (!readFully(stream, header, 2)) break
                val type = header[0]
                val nameLen = header[1].toInt() and 0xFF
                val nameBytes = ByteArray(nameLen)
                if (!readFully(stream, nameBytes, nameLen)) break
                val senderName = String(nameBytes, Charsets.UTF_8)

                val lenBytes = ByteArray(4)
                if (!readFully(stream, lenBytes, 4)) break
                val payloadLen = ((lenBytes[0].toInt() and 0xFF) shl 24) or
                        ((lenBytes[1].toInt() and 0xFF) shl 16) or
                        ((lenBytes[2].toInt() and 0xFF) shl 8) or
                        (lenBytes[3].toInt() and 0xFF)
                val payload = ByteArray(payloadLen)
                if (!readFully(stream, payload, payloadLen)) break

                when (type) {
                    PacketType.TEXT -> listener.onTextReceived(senderName, String(payload, Charsets.UTF_8))
                    PacketType.AUDIO -> listener.onAudioReceived(senderName, payload)
                }
            } catch (e: Exception) {
                break
            }
        }
        listener.onDisconnected()
    }

    private fun readFully(stream: InputStream, buffer: ByteArray, length: Int): Boolean {
        var read = 0
        while (read < length) {
            val n = stream.read(buffer, read, length - read)
            if (n < 0) return false
            read += n
        }
        return true
    }

    private fun writePacket(type: Byte, payload: ByteArray) {
        val out = outputStream ?: run {
            listener.onError("Not connected to a Bluetooth peer yet"); return
        }
        val nameBytes = myName.toByteArray(Charsets.UTF_8)
        val buffer = ByteArrayOutputStream()
        buffer.write(type.toInt())
        buffer.write(nameBytes.size)
        buffer.write(nameBytes)
        buffer.write((payload.size ushr 24) and 0xFF)
        buffer.write((payload.size ushr 16) and 0xFF)
        buffer.write((payload.size ushr 8) and 0xFF)
        buffer.write(payload.size and 0xFF)
        buffer.write(payload)
        try {
            synchronized(out) {
                out.write(buffer.toByteArray())
                out.flush()
            }
        } catch (e: Exception) {
            listener.onError("Bluetooth send failed: ${e.message}")
        }
    }

    override fun sendText(text: String) = writePacket(PacketType.TEXT, text.toByteArray(Charsets.UTF_8))

    override fun sendAudioChunk(chunk: ByteArray) = writePacket(PacketType.AUDIO, chunk)

    @SuppressLint("MissingPermission")
    override fun stop() {
        running.set(false)
        try {
            context.unregisterReceiver(discoveryReceiver)
        } catch (_: Exception) {
        }
        try {
            adapter?.cancelDiscovery()
        } catch (_: Exception) {
        }
        try {
            activeSocket?.close()
        } catch (_: Exception) {
        }
        try {
            serverSocket?.close()
        } catch (_: Exception) {
        }
        activeSocket = null
        serverSocket = null
    }
}
