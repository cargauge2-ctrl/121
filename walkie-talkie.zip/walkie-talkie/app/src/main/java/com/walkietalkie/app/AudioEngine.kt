package com.walkietalkie.app

import android.annotation.SuppressLint
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Handles microphone capture while the PTT button is held, and playback of
 * audio chunks received from a peer. Uses raw 16-bit PCM mono at 16kHz,
 * which keeps chunks small enough to push over Bluetooth/Wi-Fi/WebSocket
 * without any codec dependency.
 */
class AudioEngine {

    companion object {
        const val SAMPLE_RATE = 16000
        private val CHANNEL_IN = AudioFormat.CHANNEL_IN_MONO
        private val CHANNEL_OUT = AudioFormat.CHANNEL_OUT_MONO
        private const val ENCODING = AudioFormat.ENCODING_PCM_16BIT
    }

    private var audioRecord: AudioRecord? = null
    private var audioTrack: AudioTrack? = null
    private var recordThread: Thread? = null
    private val isRecording = AtomicBoolean(false)

    var onChunkCaptured: ((ByteArray) -> Unit)? = null

    @SuppressLint("MissingPermission")
    fun startRecording() {
        if (isRecording.get()) return
        val minBuf = AudioRecord.getMinBufferSize(SAMPLE_RATE, CHANNEL_IN, ENCODING)
        if (minBuf <= 0) return

        audioRecord = AudioRecord(
            MediaRecorder.AudioSource.VOICE_COMMUNICATION,
            SAMPLE_RATE, CHANNEL_IN, ENCODING, minBuf * 2
        )

        isRecording.set(true)
        audioRecord?.startRecording()

        recordThread = Thread {
            val buffer = ByteArray(minBuf)
            while (isRecording.get()) {
                val read = audioRecord?.read(buffer, 0, buffer.size) ?: -1
                if (read > 0) {
                    onChunkCaptured?.invoke(buffer.copyOf(read))
                }
            }
        }.also { it.start() }
    }

    fun stopRecording() {
        isRecording.set(false)
        recordThread?.join(200)
        recordThread = null
        try {
            audioRecord?.stop()
        } catch (_: Exception) {
        }
        audioRecord?.release()
        audioRecord = null
    }

    private fun ensurePlaybackReady() {
        if (audioTrack != null) return
        val minBuf = AudioTrack.getMinBufferSize(SAMPLE_RATE, CHANNEL_OUT, ENCODING)
        audioTrack = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setSampleRate(SAMPLE_RATE)
                    .setEncoding(ENCODING)
                    .setChannelMask(CHANNEL_OUT)
                    .build()
            )
            .setBufferSizeInBytes(minBuf * 2)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
        audioTrack?.play()
    }

    /** Feed a received chunk straight to the speaker. Safe to call from any thread. */
    fun playChunk(chunk: ByteArray) {
        ensurePlaybackReady()
        audioTrack?.write(chunk, 0, chunk.size)
    }

    fun release() {
        stopRecording()
        try {
            audioTrack?.stop()
        } catch (_: Exception) {
        }
        audioTrack?.release()
        audioTrack = null
    }
}
