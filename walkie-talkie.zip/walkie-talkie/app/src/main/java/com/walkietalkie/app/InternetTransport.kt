package com.walkietalkie.app

import android.util.Base64
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okhttp3.Response
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Internet mode. Connects to a small relay server (see /relay-server in this
 * project) over WebSocket, registers your username, and exchanges JSON
 * messages with whoever you address by their username. This is the only
 * mode of the three that needs a server, because two phones on different
 * networks can't normally reach each other directly.
 *
 * IMPORTANT: change RELAY_URL below to your own deployed server's address
 * before building - see the top-level README for a one-click deploy guide.
 */
class InternetTransport(
    private val myName: String,
    private val listener: TransportListener
) : Transport {

    companion object {
        // TODO: replace with your deployed relay server's wss:// URL.
        const val RELAY_URL = "wss://YOUR-RELAY-SERVER-URL/ws"
    }

    private val client = OkHttpClient.Builder()
        .pingInterval(20, TimeUnit.SECONDS)
        .build()
    private var webSocket: WebSocket? = null
    private var targetName: String = ""

    override fun start() {
        val request = Request.Builder().url(RELAY_URL).build()
        listener.onStatus("Internet: connecting to relay…")
        webSocket = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(ws: WebSocket, response: Response) {
                val register = JSONObject().apply {
                    put("type", "register")
                    put("username", myName)
                }
                ws.send(register.toString())
                listener.onStatus("Internet: registered as $myName")
            }

            override fun onMessage(ws: WebSocket, text: String) {
                handleMessage(text)
            }

            override fun onFailure(ws: WebSocket, t: Throwable, response: Response?) {
                listener.onError("Internet: connection failed (${t.message})")
            }

            override fun onClosed(ws: WebSocket, code: Int, reason: String) {
                listener.onDisconnected()
            }
        })
    }

    private fun handleMessage(text: String) {
        try {
            val json = JSONObject(text)
            when (json.optString("type")) {
                "text" -> listener.onTextReceived(json.getString("from"), json.getString("text"))
                "audio" -> {
                    val bytes = Base64.decode(json.getString("data"), Base64.NO_WRAP)
                    listener.onAudioReceived(json.getString("from"), bytes)
                }
                "registered" -> listener.onStatus("Internet: online as $myName")
                "peer_online" -> listener.onConnected(json.optString("username"))
                "error" -> listener.onError(json.optString("message", "Relay error"))
            }
        } catch (e: Exception) {
            listener.onError("Internet: bad message from relay")
        }
    }

    override fun connectTo(peerId: String) {
        // peerId is simply the username the person typed in the "Talk to" box.
        targetName = peerId
        listener.onConnected(peerId)
        listener.onStatus("Internet: ready to talk to $peerId")
    }

    override fun sendText(text: String) {
        if (targetName.isEmpty()) {
            listener.onError("Enter a username to talk to first"); return
        }
        val json = JSONObject().apply {
            put("type", "text")
            put("from", myName)
            put("to", targetName)
            put("text", text)
        }
        webSocket?.send(json.toString())
    }

    override fun sendAudioChunk(chunk: ByteArray) {
        if (targetName.isEmpty()) return
        val json = JSONObject().apply {
            put("type", "audio")
            put("from", myName)
            put("to", targetName)
            put("data", Base64.encodeToString(chunk, Base64.NO_WRAP))
        }
        webSocket?.send(json.toString())
    }

    override fun stop() {
        webSocket?.close(1000, "bye")
        webSocket = null
    }
}
