package com.walkietalkie.app

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class ChatAdapter : RecyclerView.Adapter<ChatAdapter.ViewHolder>() {

    private val items = mutableListOf<ChatMessage>()

    fun addMessage(message: ChatMessage) {
        items.add(message)
        notifyItemInserted(items.size - 1)
    }

    class ViewHolder(view: android.view.View) : RecyclerView.ViewHolder(view) {
        val sender: TextView = view.findViewById(R.id.senderLabel)
        val bubble: TextView = view.findViewById(R.id.messageBubble)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_chat_message, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]
        holder.sender.text = if (item.isMe) "You" else item.sender
        holder.bubble.text = item.text
        holder.bubble.setBackgroundResource(
            if (item.isMe) R.drawable.chat_bubble_me else R.drawable.chat_bubble_other
        )
    }

    override fun getItemCount() = items.size
}
