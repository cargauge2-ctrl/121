package com.walkietalkie.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.MotionEvent
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.walkietalkie.app.databinding.ActivityMainBinding
import java.util.UUID

enum class Mode { BLUETOOTH, WIFI_LOCAL, INTERNET }

class MainActivity : AppCompatActivity(), TransportListener {

    private lateinit var binding: ActivityMainBinding
    private lateinit var audioEngine: AudioEngine
    private lateinit var deviceAdapter: DeviceAdapter
    private lateinit var chatAdapter: ChatAdapter

    private var currentMode: Mode = Mode.WIFI_LOCAL
    private var transport: Transport? = null
    private var myName: String = ""
    private var currentPeerName: String = ""
    private var isChatOpen = false

    private val prefs by lazy { getSharedPreferences("walkie_prefs", MODE_PRIVATE) }

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            // Whatever the user grants, we proceed - transports individually
            // report an onError if something they need is still missing.
            switchMode(currentMode)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        audioEngine = AudioEngine()
        myName = loadOrCreateUsername()

        setupDeviceList()
        setupChat()
        setupModeTabs()
        setupPttButton()
        setupInternetPanel()

        binding.myUsernameInput.setText(myName)

        requestNeededPermissions()
    }

    private fun loadOrCreateUsername(): String {
        val existing = prefs.getString("username", null)
        if (existing != null) return existing
        val generated = "User-" + UUID.randomUUID().toString().take(4).uppercase()
        prefs.edit().putString("username", generated).apply()
        return generated
    }

    private fun saveUsername(name: String) {
        myName = name
        prefs.edit().putString("username", name).apply()
    }

    // ---------- Permissions ----------

    private fun requestNeededPermissions() {
        val needed = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            needed.add(Manifest.permission.BLUETOOTH_SCAN)
            needed.add(Manifest.permission.BLUETOOTH_CONNECT)
        } else {
            needed.add(Manifest.permission.BLUETOOTH)
            needed.add(Manifest.permission.BLUETOOTH_ADMIN)
        }
        needed.add(Manifest.permission.ACCESS_FINE_LOCATION)

        val missing = needed.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isEmpty()) {
            switchMode(currentMode)
        } else {
            permissionLauncher.launch(missing.toTypedArray())
        }
    }

    // ---------- UI setup ----------

    private fun setupDeviceList() {
        deviceAdapter = DeviceAdapter { peer ->
            transport?.connectTo(peer.id)
        }
        binding.deviceList.layoutManager = LinearLayoutManager(this)
        binding.deviceList.adapter = deviceAdapter
    }

    private fun setupChat() {
        chatAdapter = ChatAdapter()
        binding.chatList.layoutManager = LinearLayoutManager(this)
        binding.chatList.adapter = chatAdapter

        binding.chatToggleBtn.setOnClickListener {
            isChatOpen = !isChatOpen
            binding.chatOverlay.visibility = if (isChatOpen) android.view.View.VISIBLE else android.view.View.GONE
        }

        binding.sendMessageBtn.setOnClickListener {
            val text = binding.messageInput.text.toString().trim()
            if (text.isEmpty()) return@setOnClickListener
            transport?.sendText(text)
            chatAdapter.addMessage(ChatMessage(myName, text, isMe = true))
            binding.chatList.scrollToPosition(chatAdapter.itemCount - 1)
            binding.messageInput.setText("")
        }
    }

    private fun setupModeTabs() {
        binding.tabBluetooth.setOnClickListener { switchMode(Mode.BLUETOOTH) }
        binding.tabWifi.setOnClickListener { switchMode(Mode.WIFI_LOCAL) }
        binding.tabInternet.setOnClickListener { switchMode(Mode.INTERNET) }
    }

    private fun setupInternetPanel() {
        binding.connectInternetBtn.setOnClickListener {
            val name = binding.myUsernameInput.text.toString().trim()
            val target = binding.targetUsernameInput.text.toString().trim()
            if (name.isEmpty() || target.isEmpty()) {
                Toast.makeText(this, "Enter both your username and theirs", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (name != myName) {
                saveUsername(name)
                switchMode(Mode.INTERNET) // restart with new registered name
            }
            transport?.connectTo(target)
        }
    }

    @Suppress("MissingPermission")
    private fun setupPttButton() {
        audioEngine.onChunkCaptured = { chunk -> transport?.sendAudioChunk(chunk) }

        binding.pttButton.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                        != PackageManager.PERMISSION_GRANTED
                    ) {
                        Toast.makeText(this, "Microphone permission needed", Toast.LENGTH_SHORT).show()
                        return@setOnTouchListener true
                    }
                    updateStatusLine(statusOverride = "STATUS: transmitting…")
                    audioEngine.startRecording()
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    audioEngine.stopRecording()
                    updateStatusLine(statusOverride = "STATUS: idle")
                    true
                }
                else -> false
            }
        }
    }

    // ---------- Mode switching ----------

    private fun switchMode(mode: Mode) {
        transport?.stop()
        currentMode = mode
        currentPeerName = ""
        deviceAdapter.submitList(emptyList())

        binding.tabBluetooth.setBackgroundResource(if (mode == Mode.BLUETOOTH) R.drawable.tab_selected_bg else R.drawable.tab_unselected_bg)
        binding.tabWifi.setBackgroundResource(if (mode == Mode.WIFI_LOCAL) R.drawable.tab_selected_bg else R.drawable.tab_unselected_bg)
        binding.tabInternet.setBackgroundResource(if (mode == Mode.INTERNET) R.drawable.tab_selected_bg else R.drawable.tab_unselected_bg)

        binding.deviceList.visibility = if (mode == Mode.INTERNET) android.view.View.GONE else android.view.View.VISIBLE
        binding.internetPanel.visibility = if (mode == Mode.INTERNET) android.view.View.VISIBLE else android.view.View.GONE

        transport = when (mode) {
            Mode.BLUETOOTH -> BluetoothTransport(this, myName, this)
            Mode.WIFI_LOCAL -> WifiLocalTransport(myName, this)
            Mode.INTERNET -> InternetTransport(myName, this)
        }
        transport?.start()
        updateStatusLine(modeOverride = mode.name.replace("_", " "))
    }

    private fun updateStatusLine(
        modeOverride: String? = null,
        statusOverride: String? = null
    ) {
        val modeText = modeOverride ?: currentMode.name.replace("_", " ")
        val target = currentPeerName.ifEmpty { "--" }
        val status = statusOverride ?: "idle"
        binding.statusScreen.text = "MODE: $modeText\nME: $myName\nTARGET: $target\nSTATUS: $status"
    }

    // ---------- TransportListener ----------

    override fun onStatus(text: String) {
        runOnUiThread { updateStatusLine(statusOverride = "idle") }
    }

    override fun onPeerListChanged(peers: List<PeerDevice>) {
        runOnUiThread { deviceAdapter.submitList(peers) }
    }

    override fun onConnected(peerName: String) {
        currentPeerName = peerName
        runOnUiThread {
            updateStatusLine(statusOverride = "connected")
            Toast.makeText(this, "Connected to $peerName", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onDisconnected() {
        currentPeerName = ""
        runOnUiThread { updateStatusLine(statusOverride = "disconnected") }
    }

    override fun onTextReceived(fromName: String, text: String) {
        runOnUiThread {
            chatAdapter.addMessage(ChatMessage(fromName, text, isMe = false))
            binding.chatList.scrollToPosition(chatAdapter.itemCount - 1)
            if (!isChatOpen) {
                Toast.makeText(this, "$fromName: $text", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onAudioReceived(fromName: String, audio: ByteArray) {
        audioEngine.playChunk(audio)
    }

    override fun onError(message: String) {
        runOnUiThread { Toast.makeText(this, message, Toast.LENGTH_SHORT).show() }
    }

    override fun onDestroy() {
        super.onDestroy()
        transport?.stop()
        audioEngine.release()
    }
}
