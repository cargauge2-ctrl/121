package com.walkietalkie.app

/** A single chat message shown in the text-chat list. */
data class ChatMessage(
    val sender: String,
    val text: String,
    val isMe: Boolean,
    val timestamp: Long = System.currentTimeMillis()
)

/** A discovered / connectable peer, used by the Bluetooth and Wi-Fi Local device lists. */
data class PeerDevice(
    val id: String,          // MAC address (Bluetooth) or "ip:port" (Wi-Fi Local)
    val displayName: String,
    var connected: Boolean = false
)

/** Packet type byte used by the Bluetooth and Wi-Fi Local wire protocol. */
object PacketType {
    const val AUDIO: Byte = 0x01
    const val TEXT: Byte = 0x02
    const val DISCOVER: Byte = 0x03   // Wi-Fi Local only: "who's out there?" broadcast
    const val ANNOUNCE: Byte = 0x04   // Wi-Fi Local only: reply to DISCOVER
}

/** Callbacks a transport (Bluetooth / Wi-Fi Local / Internet) reports back to the UI. */
interface TransportListener {
    fun onStatus(text: String)
    fun onPeerListChanged(peers: List<PeerDevice>)
    fun onConnected(peerName: String)
    fun onDisconnected()
    fun onTextReceived(fromName: String, text: String)
    fun onAudioReceived(fromName: String, audio: ByteArray)
    fun onError(message: String)
}

/** Common interface all three transports implement so MainActivity can treat them the same way. */
interface Transport {
    fun start()
    fun stop()
    fun sendText(text: String)
    fun sendAudioChunk(chunk: ByteArray)
    fun connectTo(peerId: String)
}
