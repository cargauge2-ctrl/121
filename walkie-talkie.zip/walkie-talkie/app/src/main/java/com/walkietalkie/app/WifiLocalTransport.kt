package com.walkietalkie.app

import java.io.ByteArrayOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.SocketException
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Works when two phones are on the same Wi-Fi network OR one is sharing a
 * mobile hotspot the other joined - no internet required. Devices announce
 * themselves with a UDP broadcast; once you tap a discovered peer, audio and
 * text packets are sent point-to-point over UDP on the same port.
 */
class WifiLocalTransport(
    private val myName: String,
    private val listener: TransportListener
) : Transport {

    companion object {
        const val PORT = 45999
        private const val DISCOVER_INTERVAL_MS = 3000L
    }

    private var socket: DatagramSocket? = null
    private val running = AtomicBoolean(false)
    private val peers = CopyOnWriteArrayList<PeerDevice>()
    private var targetAddress: InetSocketAddress? = null
    private var targetName: String = ""

    override fun start() {
        if (running.get()) return
        running.set(true)
        try {
            socket = DatagramSocket(null).apply {
                reuseAddress = true
                bind(InetSocketAddress(PORT))
                broadcast = true
            }
        } catch (e: SocketException) {
            listener.onError("Wi-Fi Local: couldn't open port $PORT (${e.message})")
            running.set(false)
            return
        }

        listener.onStatus("Wi-Fi Local: listening on port $PORT")

        Thread { receiveLoop() }.start()
        Thread { discoveryLoop() }.start()
    }

    override fun stop() {
        running.set(false)
        socket?.close()
        socket = null
        targetAddress = null
    }

    override fun connectTo(peerId: String) {
        val peer = peers.find { it.id == peerId } ?: return
        val parts = peer.id.split(":")
        if (parts.size != 2) return
        targetAddress = InetSocketAddress(parts[0], parts[1].toInt())
        targetName = peer.displayName
        listener.onConnected(peer.displayName)
        listener.onStatus("Wi-Fi Local: talking to ${peer.displayName}")
    }

    override fun sendText(text: String) {
        val addr = targetAddress ?: run {
            listener.onError("Pick a Wi-Fi Local peer first"); return
        }
        sendPacket(PacketType.TEXT, text.toByteArray(Charsets.UTF_8), addr)
    }

    override fun sendAudioChunk(chunk: ByteArray) {
        val addr = targetAddress ?: return
        sendPacket(PacketType.AUDIO, chunk, addr)
    }

    private fun sendPacket(type: Byte, payload: ByteArray, addr: InetSocketAddress) {
        val nameBytes = myName.toByteArray(Charsets.UTF_8)
        val out = ByteArrayOutputStream()
        out.write(type.toInt())
        out.write(nameBytes.size)
        out.write(nameBytes)
        out.write(payload)
        val data = out.toByteArray()
        try {
            socket?.send(DatagramPacket(data, data.size, addr))
        } catch (e: Exception) {
            listener.onError("Wi-Fi Local send failed: ${e.message}")
        }
    }

    private fun discoveryLoop() {
        while (running.get()) {
            try {
                val nameBytes = myName.toByteArray(Charsets.UTF_8)
                val out = ByteArrayOutputStream()
                out.write(PacketType.DISCOVER.toInt())
                out.write(nameBytes.size)
                out.write(nameBytes)
                val data = out.toByteArray()
                val broadcastAddr = InetAddress.getByName("255.255.255.255")
                socket?.send(DatagramPacket(data, data.size, broadcastAddr, PORT))
            } catch (_: Exception) {
                // network may be briefly unavailable; just retry next cycle
            }
            Thread.sleep(DISCOVER_INTERVAL_MS)
        }
    }

    private fun receiveLoop() {
        val buf = ByteArray(4096)
        while (running.get()) {
            try {
                val packet = DatagramPacket(buf, buf.size)
                socket?.receive(packet)
                handlePacket(packet)
            } catch (e: Exception) {
                if (running.get()) {
                    // socket likely closed on stop(); loop will exit next check
                }
            }
        }
    }

    private fun handlePacket(packet: DatagramPacket) {
        val data = packet.data
        if (packet.length < 2) return
        val type = data[0]
        val nameLen = data[1].toInt() and 0xFF
        if (packet.length < 2 + nameLen) return
        val senderName = String(data, 2, nameLen, Charsets.UTF_8)
        val payloadOffset = 2 + nameLen
        val payloadLen = packet.length - payloadOffset

        when (type) {
            PacketType.DISCOVER -> {
                // Someone is looking for peers - reply with ANNOUNCE so they see us.
                val myBytes = myName.toByteArray(Charsets.UTF_8)
                val out = ByteArrayOutputStream()
                out.write(PacketType.ANNOUNCE.toInt())
                out.write(myBytes.size)
                out.write(myBytes)
                val replyData = out.toByteArray()
                try {
                    socket?.send(DatagramPacket(replyData, replyData.size, packet.address, PORT))
                } catch (_: Exception) {
                }
            }
            PacketType.ANNOUNCE -> {
                val id = "${packet.address.hostAddress}:$PORT"
                if (senderName != myName && peers.none { it.id == id }) {
                    peers.add(PeerDevice(id, senderName))
                    listener.onPeerListChanged(peers.toList())
                }
            }
            PacketType.TEXT -> {
                val text = String(data, payloadOffset, payloadLen, Charsets.UTF_8)
                listener.onTextReceived(senderName, text)
            }
            PacketType.AUDIO -> {
                val audio = data.copyOfRange(payloadOffset, payloadOffset + payloadLen)
                listener.onAudioReceived(senderName, audio)
            }
        }
    }
}
